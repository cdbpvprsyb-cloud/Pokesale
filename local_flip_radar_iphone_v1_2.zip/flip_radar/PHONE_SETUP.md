# Local Flip Radar — iPhone-first setup

The iPhone is the client. The scanner/web server runs in the cloud, so Safari does not need to remain open.

## Deploy
1. Put this folder in a private GitHub repository.
2. Create a Python web service on your hosting provider (Render-compatible `render.yaml` is included).
3. Build: `pip install -r requirements.txt`
4. Start: `gunicorn app:app --bind 0.0.0.0:$PORT --workers 1 --threads 4 --timeout 60`
5. Add the environment variables from `.env.example` in the host dashboard. Never commit real Twilio credentials.
6. For continuous scanning, run `python worker.py` as a separate background worker/service. If the host does not support workers on your plan, run it as a second service.

## iPhone
Open the deployed HTTPS address in Safari, tap Share, then Add to Home Screen. The included PWA manifest/service worker makes it launch in standalone mode.

## SMS
Set TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM, and SMS_TO on the cloud host. SMS fires only when an opportunity clears the configured SMS profit/ROI thresholds.

## Important storage note
SQLite is fine for testing. On cloud hosts with ephemeral disks, data can reset on redeploy/restart. For durable production history, attach persistent storage or migrate to hosted Postgres before relying on long-term history.
