import time
from app import scan_all, SCAN_MINUTES
if __name__ == '__main__':
    print(f'Flip Radar worker started; scanning every {SCAN_MINUTES} minutes', flush=True)
    while True:
        scan_all()
        time.sleep(max(1, SCAN_MINUTES) * 60)
