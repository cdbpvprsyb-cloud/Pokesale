# Local Flip Radar

Personal retail-arbitrage dashboard for two Maryland zones: Huntingtown/Prince Frederick and a 10-mile Beltsville work zone.

## Run
1. Install Python 3.11+.
2. `python -m venv .venv`
3. macOS/Linux: `source .venv/bin/activate` — Windows: `.venv\\Scripts\\activate`
4. `pip install -r requirements.txt`
5. Copy `.env.example` to `.env` and optionally enter Twilio credentials.
6. `python app.py`
7. Open `http://127.0.0.1:5000`

## What works immediately
- SQLite persistence
- Home/work store list
- Mobile-friendly dashboard
- Add an observed item and its market value
- Conservative estimated net profit: market value minus 13.25% selling fee, $5 fulfillment allowance, and retail cost
- ROI ranking/highlighting
- Twilio SMS for items meeting SMS thresholds
- Background retailer-page monitoring every 10 minutes
- `/health` and `/api/opportunities`

## Important inventory limitation
Retailers increasingly render local quantity/availability behind client-side services and bot controls. The included generic collector intentionally does not bypass those controls. It checks public retailer pages and records watch-term page matches. Exact automated local-stock adapters should use a retailer-approved API/feed where available. The dashboard, database, scoring, scheduling and SMS pipeline are independent of those adapters, so a retailer change does not break the app.

## SMS
Create a Twilio number, then set `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_FROM`, and `SMS_TO` in `.env`. Without credentials, the rest of the app still works.

## Deploy
A small always-on VM works well. Run `gunicorn -b 0.0.0.0:$PORT app:app` behind HTTPS. For the built-in background scheduler, use one Gunicorn worker, or move scheduling to cron/another process.

## Expanded retailer coverage (v1.1)
The seed store list now includes nearby Dollar Tree, ALDI, and Sam's Club locations in the Home/Work corridors. The scanner watch terms also include dollar-store collectibles, warehouse limited/clearance merchandise, and ALDI Finds/Special Buys.

Notes:
- Dollar General is a high-priority Pokemon source and its public catalog exposes Pokemon products. Add exact local DG locations as verified store pages are identified.
- Dollar Tree/Family Dollar are treated as discovery sources because SKU-level local stock can be inconsistent online.
- Sam's Club is monitored for Pokemon/collectibles plus limited and clearance general merchandise.
- ALDI is monitored primarily for weekly ALDI Finds (toys, home, seasonal, apparel and other limited-run merchandise), not just Pokemon.
